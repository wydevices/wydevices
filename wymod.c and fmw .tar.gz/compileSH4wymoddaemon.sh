/ZTV/opt/crosstool/gcc-4.1.1-glibc-2.6.1/sh4-unknown-linux-gnu/bin/sh4-unknown-linux-gnu-gcc-4.1.1 -Wall wymod.c mongoose.c -ldl -lpthread -o wymoddaemon
