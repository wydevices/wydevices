<pre>
<?php
system ("tar -zxvf /wymedia/usr/share/updates/* -C /wymedia/");

echo ("<b><h2> You can now close this window!<h2></b>");
?>
</pre>