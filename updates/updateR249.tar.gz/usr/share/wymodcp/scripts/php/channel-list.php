<html>
<head><script src="../js/wydev.js" type="text/javascript"></script></head>
<body >
<h2>Channel List</h2>
<div id="channellist"><?php include 'channelform.php' ?></div>
</body>
</html>



