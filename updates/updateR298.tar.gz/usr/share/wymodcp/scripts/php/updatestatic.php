<pre>
<?php
system ("tar -zxvf /wymedia/usr/share/updates/static/*.tar.gz -C /wymedia/");
echo ("<b><h2> You can now close this window!<h2></b>");
?>
</pre>