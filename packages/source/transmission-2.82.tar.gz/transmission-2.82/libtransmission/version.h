#define PEERID_PREFIX             "-TR2820-"
#define USERAGENT_PREFIX          "2.82"
#define SVN_REVISION              "14160"
#define SVN_REVISION_NUM          14160
#define SHORT_VERSION_STRING      "2.82"
#define LONG_VERSION_STRING       "2.82 (14160)"
#define VERSION_STRING_INFOPLIST  2.82
#define MAJOR_VERSION             2
#define MINOR_VERSION             82
#define TR_STABLE_RELEASE         1
