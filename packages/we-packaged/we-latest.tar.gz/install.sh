## Instala los wybox-extras

# Para los servicios
if [ -e /wymedia/usr/etc/init.d ]; then
	for service in $( ls /wymedia/usr/etc/init.d ); do
		if [ ! $service == "wymodcp" ]; then
			/wymedia/usr/etc/init.d/$service stop > /dev/null 2>&1
		fi
	done
fi

# Realiza copias de seguridad
rm -rf /wymedia/Backup/we-tmp
mkdir -p /wymedia/Backup/we-tmp
if [ -f /wymedia/usr/etc/inadyn.conf ]; then
	mv -f /wymedia/usr/etc/inadyn.conf /wymedia/Backup/we-tmp
fi
mv -f /wymedia/usr/etc/pureftpd.passwd /wymedia/Backup/we-tmp
mv -f /wymedia/usr/etc/rc.d /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/imagepacks /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/skins /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/wymodcp/docs /wymedia/Backup/we-tmp
mv -f /wymedia/usr/bin/ffmpeg /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/doc /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/psfreedom /wymedia/Backup/we-tmp
mv -f /wymedia/usr/share/pygui /wymedia/Backup/we-tmp
sync

# Desempaqueta los wybox-extras
rm -rf /wymedia/usr
tar zxf /wymedia/tmp/wybox-extras-0.5-r435.tar.gz -C /wymedia/
sync

# Restaura las copias de seguridad
if [ -f /wymedia/Backup/we-tmp/inadyn.conf ]; then
	mv -f /wymedia/Backup/we-tmp/inadyn.conf /wymedia/usr/etc
fi
mv -f /wymedia/Backup/we-tmp/pureftpd.passwd /wymedia/usr/etc
mv -f /wymedia/Backup/we-tmp/rc.d/* /wymedia/usr/etc/rc.d
mv -f /wymedia/Backup/we-tmp/imagepacks /wymedia/usr/share
mv -f /wymedia/Backup/we-tmp/skins /wymedia/usr/share
mv -f /wymedia/Backup/we-tmp/docs/* /wymedia/usr/share/wymodcp/docs
mv -f /wymedia/Backup/we-tmp/ffmpeg /wymedia/usr/bin
mv -f /wymedia/Backup/we-tmp/doc /wymedia/usr/share
mv -f /wymedia/Backup/we-tmp/psfreedom /wymedia/usr/share
mv -f /wymedia/Backup/we-tmp/pygui /wymedia/usr/share
rm -rf /wymedia/Backup/we-tmp
sync

# Asegura que wymodcp, syslogd y crond se activen en el arranque
if [ ! -d /wymedia/usr/etc/rc.d ]; then
	mkdir /wymedia/usr/etc/rc.d
fi
ln -sf /wymedia/usr/etc/init.d/wymodcp /wymedia/usr/etc/rc.d/wymodcp
ln -sf /wymedia/usr/etc/init.d/syslogd /wymedia/usr/etc/rc.d/syslogd
ln -sf /wymedia/usr/etc/init.d/crond /wymedia/usr/etc/rc.d/crond
sync

# Actualiza /wymedia/usr/etc/wydev-mod-updaterelease
echo "435" > /wymedia/usr/etc/wydev-mod-updaterelease

##
