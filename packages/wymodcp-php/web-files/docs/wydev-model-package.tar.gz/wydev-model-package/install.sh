#!/bin/sh
#
# This script is run for install your package
#

touch /wymedia/tmp/model_package_installed
echo "wydev-model-package installed on `date`"

