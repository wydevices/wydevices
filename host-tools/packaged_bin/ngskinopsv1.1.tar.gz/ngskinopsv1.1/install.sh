echo "replacing __init__.py"
mv /wymedia/usr/share/updates/ngskinopsv1.1/__init__.py /usr/lib/python2.5/site-packages/pygui/__init__.py
echo "replacing themes.py"
mv /wymedia/usr/share/updates/ngskinopsv1.1/themes.py /usr/lib/python2.5/site-packages/pygui/item/parameters/generalsetup/themes.py
echo "Starting installation of skinops v1.1"
mv /wymedia/usr/share/updates/ngskinopsv1.1/ngskinops /wymedia/usr/bin/ngskinops
echo "Setting execute permision"
chmod +x /wymedia/usr/bin/ngskinops
echo "Installation finished"
rm -Rf /wymedia/usr/share/updates/ngskinopsv1.1/

echo `ls /wymedia/usr/bin/ngskinops`
echo `ls /usr/lib/python2.5/site-packages/pygui/__init__.py `
echo `ls /usr/lib/python2.5/site-packages/pygui/item/parameters/generalsetup/themes.py`

