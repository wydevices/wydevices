# -*- coding: utf-8 -*- 
#
# Description:
# Theme Parameters Items Class Definitions
#
# Changes:
#
# 2011-11-18
# Initial Commit
#
# Copyright 2010-2012, WyDev Team.
# Author: Polo35 (polo35580@hotmail.fr)
#
# Licenced under Academic Free License version 3.0
# Review WyGui README & LICENSE files for further details.

from __future__ import absolute_import

import os

from peewee.debug import PRINT_EXCEPTION
from pygui.facilities.l10n import UnicodeDict
from pygui.item.core import ActionItem
from pygui.item.parameters import UserConfigSetupItem, ParametersSetupItem
from pygui.window import ConfirmWindow
from pygui.window.core import Button

# THEMES_ENGINES = UnicodeDict({'wybox': 'Wyplayer', 'zoltartv': 'ZoltarTV', 'mediatec': 'MediaTec', 'mediatitan': 'MediaTitan'})
THEMES_ENGINES = UnicodeDict({'wybox': 'Wyplayer', 'zoltartv': 'ZoltarTV', 'mediatec': 'MediaTec', 'mediatitan': 'MediaTitan', 'skinops':'Skinops'})
# THEMES_ENGINES = UnicodeDict({'wybox': 'Wyplayer', 'zoltartv': 'ZoltarTV', 'mediatec': 'MediaTec', 'mediatitan': 'MediaTitan', 'kiwy':'Kiwy', 'skinops':'Skinops'})
THEMES_SERIALIZED = UnicodeDict({True: 'ON', False: 'OFF'})

class ThemeEngineUserConfigSetupItem(UserConfigSetupItem):

	translation_dict = THEMES_ENGINES


class SerializedThemeUserConfigSetupItem(UserConfigSetupItem):

	translation_dict = THEMES_SERIALIZED
	
class ApplyThemesActionItem(ActionItem):

	def __init__(self, *args, **kw):
		ActionItem.__init__(self, action=self._check_action, **kw)

	def _check_action(self):
		w = ConfirmWindow(text=_(_('Modifications will take effect after reboot.\nDo you want to reboot now ?')), confirm_action=self.restart_gui, buttons=[Button(_('Yes'), False), Button(_('No'), True)])
		w.show()

	def restart_gui(self):
		os.system('/sbin/reboot')

class ThemesParametersSetupItem(ParametersSetupItem):

	depth = 3

	def __init__(self, *args, **kw):
		ParametersSetupItem.__init__(self, *args, **kw)
		return None

	def browse(self, preview=False):
		preview_list = [ThemeEngineUserConfigSetupItem(name='Engine', menu=self.menu, domain='base', key='theme_engine', choices_list=sorted(THEMES_ENGINES, reverse=False)),
				SerializedThemeUserConfigSetupItem(name='Serialized (Speed up boot)', menu=self.menu, domain='base', key='use_serialized_theme', choices_list=sorted(THEMES_SERIALIZED, reverse=False)),
				ApplyThemesActionItem(name=_('Apply'), type_='action')]
		return preview_list
