# -*- coding: utf-8 -*- 
#
# Description:
#
# WyGui 1.3.0 Entry Point
#
#
#
# Changes:
#
# 2011-10-02
# Remove Argv handling (not use)
# Remove DemoMode (not use) & force that it's never use
#
# 2011-11-18
# Add "theme engine" handling
#
#
# Little story about the WyGui Startup.
#
# InitNG start "system->splash.i".
# "splash.i" call "exec daemon = /usr/bin/python2.5 -O /usr/bin/splash.py"
# "splash.py" load splash screen and call "pygui.startup(display, boot)"
#
#
# Copyright 2010-2012, WyDev Team.
# Author: Polo35 (polo35580@hotmail.fr)
#
# Licenced under Academic Free License version 3.0
# Review WyGui README & LICENSE files for further details.


from __future__ import absolute_import

import gettext
gettext.NullTranslations().install()


# WyGui Version definition
__version__ = '1.3.0'



####################################
# ***Startup procedure***
# Fonction arguments:
# 1 - display
#   Current display started by "splash.py".
# 2 - previous_objects
#   Object to remove from screen after splash.
####################################
def startup(display=None, previous_objects=None):

	import os
	import sys
	import pygui.config as config
	from peewee import debug

	# Set config depending on theme engine
	if 'wybox' in config.user_config['base']['theme_engine']:
		config.plugins.add('universe_switcher')
		config.plugins.add('restore_last_universe')
		config.plugins.discard('home.acquisition')
		config.horizontal_selector=True
	elif 'zoltartv' in config.user_config['base']['theme_engine']:
		config.plugins.discard('universe_switcher')
		config.plugins.discard('restore_last_universe')
		config.plugins.discard('home.acquisition')
	elif 'mediatitan' in config.user_config['base']['theme_engine']:
		config.plugins.discard('universe_switcher')
		config.plugins.discard('restore_last_universe')
		config.plugins.discard('home.acquisition')
		config.horizontal_selector=True
	elif 'mediatec' in config.user_config['base']['theme_engine']:
		config.plugins.discard('universe_switcher')
		config.plugins.discard('restore_last_universe')
		config.horizontal_selector=True
		config.home_order = ['tv', 'audio', '*video_image', 'net_services',  'parameters']
	elif 'kiwy' in config.user_config['base']['theme_engine']:
		config.plugins.add('universe_switcher')
		config.plugins.add('restore_last_universe')
		config.plugins.discard('home.acquisition')
		config.horizontal_selector=True
	elif 'skinops' in config.user_config['base']['theme_engine']:
		config.plugins.add('universe_switcher')
		config.plugins.add('restore_last_universe')
		config.plugins.discard('home.acquisition')
		config.horizontal_selector=True

	# WyMedia Import
	try:
		import wymedia
	except (ImportError, AssertionError):
		import fakewymedia
		sys.modules['wymedia'] = fakewymedia

	# Fake DBUS Import if needed
	if config.no_DBUS:
		import fakewydbus
		sys.modules['wydbus'] = fakewydbus

	###################################
	# Deferred Startup
	###################################
	def deferred_startup():
		debug.log.debug('Loading deferred')
		
		# Init Everything
		from pygui.deferred_startup import init_startup
		init_startup()
		
		# Tell InitNG that everything is started
		try:
			file('/tmp/ready', 'w')
		except:
			pass
		
		# Start Debugger if needed
		if os.environ.get('RPDB') or 'rpdb' in config.plugins:
			import rpdb2
			rpdb2.start_embedded_debugger('pygui', fAllowRemote=True, timeout=60)
			print 'RPDB2 Started'
		
		# Configure Socket
		import socket
		socket.setdefaulttimeout(config.socket_timeout)


	# Starting Logger
	debug.log = debug.GET_LOGGER('pygui')
	
	# Loading Internationalisation
	from pygui.facilities import l10n
	l10n.set_language()


	###################################
	# WyGui Entry Point
	###################################
	def main(display, previous_objects):

		# Parse Arguments
		from pygui.facilities.optionparser import parser
		options, args = parser.parse_args()

		# Init Timers
		try:
			from peewee.dateutils import TimeManager, WYCLOCK_AUTO_SETTER
			if config.user_config['base']['firstboot']:
				config.user_config['base']['timeupdatemode'] = WYCLOCK_AUTO_SETTER
			TimeManager().time_setter = config.user_config['base']['timeupdatemode']
		except:
			debug.PRINT_EXCEPTION()
			debug.log.error('Time configuration failed')

		# WyGui Startup
		try:
			# Display Init
			try:
				# Wyvas Import
				try:
					import wyvas
				except (ImportError, AssertionError):
					print 'Unable to load wyvas, loading fakevas...\n'
					wyvas = __import__('fakevas')
					sys.modules['wyvas'] = wyvas
				
				# Create Display if needed
				if display is None:
					display = wyvas.Canvas(
													(config.display_width, config.display_height),
													event = 1 if  "input.dfbevents" in config.plugins else 0 ,
													font_path = os.path.join(config.themes_dir, 'fonts'),
													fps = config.fps,
													key_repeat = config.key_repeat,
													queue_size = config.queue_size)
			except Exception, e:
				print 'Unable to initialize main Canvas, program exits:\n'
				raise SystemExit(str(e))   

			# Init Vars
			from pygui.shared import pygui_globs
			pygui_globs['display'] = display
			pygui_globs['demomode'] = None
			pygui_globs['wydbus'] = None

			# Init Menu Manager
			from pygui.menu.stack import MenuManager
			menumanager = MenuManager()

			# Init Menu Engine
			import pygui.gui.engine as gui_engine
			engine = gui_engine.ViewManager(display, config.user_config['base']['theme_engine'])
			engine_loader = engine.loader_iterator()
			engine_loader.next()
			menumanager.engines.append(engine)

			# Import Root & Home Menus
			from pygui.menu.menu.home import RootMenu, HomeMenu

			# ???
			if len(sys.argv)>1:
				focus = sys.argv[-1]
			else:
				focus = False

			# Remove previous objects from screen
			if previous_objects:
				for name, oo in previous_objects.iteritems():
					if name.startswith('bar'):
						oo.unparent()
					else:
						oo.animate('color', a=0, duration=2, end_callback=oo.unparent)
				previous_objects.clear()

			# Start Root & Home Menus
			import peewee.notifier as notifier
			RootMenu().show()
			HomeMenu().show()

			# Restore Last Universe if needed
			if 'restore_last_universe' in config.plugins and not config.user_config['base']['firstboot']:
				def load_and_restore():
					yield None
					for i in engine_loader:
						yield None
					from pygui.facilities.power import restore_last_universe
					restore_last_universe()
				notifier.Task(load_and_restore().next).start(1.0, loop=True)
			else:
				notifier.Task(engine_loader.next).start(1.0, loop=True)

			# Start Event Logger if needed
			if 'event_logger' in config.plugins:
				from pygui.facilities.eventlogger import EventLoggerPlugin
				EventLoggerPlugin()

			# Start FirstBoot Menu if needed
			if config.user_config['base']['firstboot']:
				engine_loader.next()
				from pygui.menu.menu.firstboot import FirstBootMenu
				notifier.Task(FirstBootMenu().show()).start(10)
			else:
				# Start DemoMode Menu if needed
#				if config.user_config['advanced']['demo_mode'] and config.user_config['advanced']['start_on_demo_mode']:
#					from pygui.item.parameters.advanced import LaunchDemoItem
#					notifier.Task(LaunchDemoItem(_('Run demo mode')).execute()).start(10)
				# Remove DemoMode
				config.user_config['advanced']['demo_mode'] = False
				config.user_config['advanced']['start_on_demo_mode'] = False
				config.user_config.save()

			# Init PowerManager
			try:
				from pygui.facilities.power import PowerManager
				PowerManager().notify_new_max_power_state(3)
			except:
				debug.PRINT_EXCEPTION()

		except Exception, e:
			debug.PRINT_EXCEPTION(e)

		# Call "deferred_startup"
		notifier.Task(deferred_startup).start(7)

		# Loop forever
		notifier.loop()

		# End of Main
		return None


	# Init WyGui with Analyse if needed
	if config.code_coverage:
		from peewee import analyse
		analyse.Cover().start((lambda : main(display, previous_objects)))
	# Init WyGui with Profiling if needed
	elif config.code_profiler:
		from peewee import analyse
		analyse.Profiler().start((lambda : main(display, previous_objects)))
	# Init WyGui
	else:
		main(display, previous_objects)

	print '\nbye bye!\n'



if __name__ == '__main__':
	startup()
