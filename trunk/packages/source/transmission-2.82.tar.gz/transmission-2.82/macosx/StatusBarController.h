/******************************************************************************
 * $Id: StatusBarController.h 13343 2012-06-10 13:47:32Z livings124 $
 * 
 * Copyright (c) 2011-2012 Transmission authors and contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/

#import <Cocoa/Cocoa.h>

#import <transmission.h>

@interface StatusBarController : NSViewController
{
    IBOutlet NSButton * fStatusButton;
    IBOutlet NSTextField * fTotalDLField, * fTotalULField;
    IBOutlet NSImageView * fTotalDLImageView, * fTotalULImageView;
    
    tr_session * fLib;
    
    CGFloat fPreviousDownloadRate, fPreviousUploadRate;
}

- (id) initWithLib: (tr_session *) lib;

- (void) updateWithDownload: (CGFloat) dlRate upload: (CGFloat) ulRate;
- (void) setStatusLabel: (id) sender;

- (void) updateSpeedFieldsToolTips;

@end
